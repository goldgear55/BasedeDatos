<?php

const ELECTRODOMESTICO = "ELECTRODOMESTICO";
const E_ID = "E_ID";
const E_NOMBRE = "E_NOMBRE";
const PRECIO = "PRECIO";
const COLOR = "COLOR";
